from ans import biggest_room_area as a
from full import data

for i, j in data:
    print(a(i) == j)

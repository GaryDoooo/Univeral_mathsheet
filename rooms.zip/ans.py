def biggest_room_area(layout):
    return 0
